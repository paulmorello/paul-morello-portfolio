import React from 'react';

const Slogan = React.createClass({

  render: function() {
    return (
      <h5 className="main-heading-slogan">Ruby on Rails. JavaScript. React. HTML. CSS.</h5>
    )
  }
})

module.exports = Slogan;
