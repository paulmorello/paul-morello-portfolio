import React from 'react'

const MainHeader = React.createClass({

  render: function() {
    return (
      <h1 className="main-heading">PAUL MORELLO.</h1>
    )
  }
})

module.exports = MainHeader;
